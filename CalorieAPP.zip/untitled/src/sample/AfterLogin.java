package sample;
import java.io.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.io.IOException;


public class AfterLogin {

    @FXML
    private TextField name,age,height,weight;

    @FXML
    private Button nextbutton;


/*String username= name.getText().toString();
String user_age= age.getText();
String user_height= height.getText();
String user_weight=weight.getText();*/
public void backtologin(ActionEvent event)throws IOException{
    //Main m= new Main();
    //m.changeScene("sample.fxml");
    Parent sceneparent1= FXMLLoader.load(getClass().getResource("PickFood.fxml"));
    Scene childscene1=new Scene(sceneparent1);
    Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
    window.setTitle("Calculate calories");
    window.setScene(childscene1);
    window.show();
}
}

