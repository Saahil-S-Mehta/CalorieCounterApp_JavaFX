package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;

public class PickFood {

    @FXML
    private Button caloriesButton;
    @FXML
    private CheckBox rice,roti,dal,apple,banana;
    @FXML
    private TextField riceval,rotival,dalval,appleval,bananaval,test;
    @FXML
    //private Label lab1;

 int calrice=100,calroti=80,caldal=75,calapple=40,calbanana=60;
  int rval=0,rval2=0,rval3=0,rval4=0,rval5=0;
  int vh;
    public void calcCal(javafx.event.ActionEvent actionEvent) {

        if(rice.isSelected())
            rval = Integer.parseInt(riceval.getText());

        if(roti.isSelected())
            rval2 = Integer.parseInt(rotival.getText());
        if(dal.isSelected())
            rval3 = Integer.parseInt(dalval.getText());
        if(apple.isSelected())
            rval4 = Integer.parseInt(appleval.getText());
        if(banana.isSelected())
            rval5 = Integer.parseInt(bananaval.getText());
         vh=(rval*calrice) +(rval2*calroti)+(rval3*caldal)+(rval4*calapple)+(rval5*calbanana);
         test.setText(""+vh);
        }

    }

