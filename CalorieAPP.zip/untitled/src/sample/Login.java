package sample;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.io.IOException;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Login {

    @FXML
    private Button loginbutton;
    @FXML
    private TextField username;
    @FXML
    private Label wronglogin;
    @FXML
    private PasswordField password;

    public void userLogin(ActionEvent event)throws IOException {
        changeScene(event);
    }
    public void changeScene(ActionEvent event) throws IOException {
        if(username.getText().toString().equals("admin") && password.getText().toString().equals("1234")) {

            wronglogin.setText("Login Success");
            Parent sceneparent= FXMLLoader.load(getClass().getResource("AfterLogin.fxml"));
            Scene childscene=new Scene(sceneparent);

            Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
            window.setTitle("Enter User Data");
            window.setScene(childscene);
            window.show();

        }
        else if(username.getText().isEmpty() && password.getText().isEmpty()){

            wronglogin.setText("Please enter your Credentials");
        }
        else{
            wronglogin.setText("Wrong username or Password");
        }

    }
       /* private void checkLogin() throws IOException{
            Main m=new Main();


     }*/

}



